
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Definir Horários de Atendimento')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    
    <?php if(session('success')): ?>
        <div class="py-4">
            <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="py-12">
        <div class="max-w-4xl mx-auto sm:px-6 lg:px-8">
            
            <div class="mb-6">
                <form method="GET" action="<?php echo e(route('schedule.edit')); ?>">
                    <label for="barber" class="block font-medium text-sm text-gray-700 dark:text-gray-300">Selecione um Barbeiro para Editar</label>
                    <div class="flex items-center mt-1">
                        <select name="barber" id="barber" onchange="this.form.submit()" class="block w-full rounded-md border-gray-300 shadow-sm dark:bg-gray-700 dark:border-gray-600">
                            <?php $__currentLoopData = $barbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($barber->id); ?>" <?php if($barber->id == $selectedBarber->id): ?> selected <?php endif; ?>>
                                    <?php echo e($barber->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </form>
            </div>

            
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 md:p-8 text-gray-900 dark:text-gray-100">
                    <h3 class="text-xl font-bold mb-4">Editando horários de: <span class="text-indigo-600"><?php echo e($selectedBarber->name); ?></span></h3>
                    <form method="POST" action="<?php echo e(route('schedule.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        
                        <input type="hidden" name="barber_id" value="<?php echo e($selectedBarber->id); ?>">

                        <div class="space-y-6">
                            <?php $__currentLoopData = $daysOfWeek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayIndex => $dayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="p-4 border rounded-lg dark:border-gray-600">
                                    <h3 class="font-semibold text-lg mb-3"><?php echo e($dayName); ?></h3>
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                                        <div class="flex items-center space-x-2">
                                            <input type="checkbox" name="schedules[<?php echo e($dayIndex); ?>][enabled]" id="enabled_<?php echo e($dayIndex); ?>"
                                                   <?php if(isset($scheduleByDay[$dayIndex])): ?> checked <?php endif; ?>>
                                            <label for="enabled_<?php echo e($dayIndex); ?>">Trabalha neste dia</label>
                                        </div>
                                        <div>
                                            <label for="start_time_<?php echo e($dayIndex); ?>" class="block text-sm font-medium">Início</label>
                                            <input type="time" name="schedules[<?php echo e($dayIndex); ?>][start_time]" id="start_time_<?php echo e($dayIndex); ?>"
                                                   value="<?php echo e($scheduleByDay[$dayIndex]['start_time'] ?? ''); ?>"
                                                   class="mt-1 block w-full rounded-md ...">
                                        </div>
                                        <div>
                                            <label for="end_time_<?php echo e($dayIndex); ?>" class="block text-sm font-medium">Fim</label>
                                            <input type="time" name="schedules[<?php echo e($dayIndex); ?>][end_time]" id="end_time_<?php echo e($dayIndex); ?>"
                                                   value="<?php echo e($scheduleByDay[$dayIndex]['end_time'] ?? ''); ?>"
                                                   class="mt-1 block w-full rounded-md ...">
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="flex items-center justify-end mt-8">
                            <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                <?php echo e(__('Salvar Horários')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sysagenda\resources\views/schedule/edit.blade.php ENDPATH**/ ?>