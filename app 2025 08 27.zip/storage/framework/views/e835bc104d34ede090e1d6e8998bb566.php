<?php if (isset($component)) { $__componentOriginalaa758e6a82983efcbf593f765e026bd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa758e6a82983efcbf593f765e026bd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::message'),'data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mail::message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
# Olá, <?php echo new \Illuminate\Support\EncodedHtmlString($appointment->customer_name); ?>!

O seu agendamento foi confirmado com sucesso.

Aqui estão os detalhes:

**Serviço:** <?php echo new \Illuminate\Support\EncodedHtmlString($appointment->service->name); ?>

**Profissional:** <?php echo new \Illuminate\Support\EncodedHtmlString($appointment->barber->name); ?>

**Data:** <?php echo new \Illuminate\Support\EncodedHtmlString($appointment->start_at->format('d/m/Y')); ?>

**Hora:** <?php echo new \Illuminate\Support\EncodedHtmlString($appointment->start_at->format('H:i')); ?>


Obrigado por escolher os nossos serviços!

Atenciosamente,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $attributes = $__attributesOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $component = $__componentOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__componentOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\sysagenda\resources\views/emails/appointments/confirmed.blade.php ENDPATH**/ ?>