<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Plan;

class PlanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Apaga os planos existentes para evitar duplicados ao rodar o seeder várias vezes
        Plan::truncate();

        Plan::create([
            'name' => 'Plano Bronze',
            'slug' => 'bronze',
            'stripe_plan_id' => 'price_exemplo_bronze', // Exemplo
            'price' => 1990, // R$ 19,90 em cêntimos
            'description' => 'Para o profissional autônomo.',
            'barber_limit' => 1, // Limite de 1 barbeiro
        ]);

        Plan::create([
            'name' => 'Plano Prata',
            'slug' => 'prata',
            'stripe_plan_id' => 'price_exemplo_prata', // Exemplo
            'price' => 3990, // R$ 39,90 em cêntimos
            'description' => 'Ideal para pequenas equipes.',
            'barber_limit' => 3, // Limite de até 3 barbeiros
        ]);

        Plan::create([
            'name' => 'Plano Ouro',
            'slug' => 'ouro',
            'stripe_plan_id' => 'price_exemplo_ouro', // Exemplo
            'price' => 7990, // R$ 79,90 em cêntimos
            'description' => 'Para negócios em crescimento, sem limites.',
            'barber_limit' => 1000, // Usamos um número alto para representar "ilimitado"
        ]);
    }
}