<?php
// Em app/Http/Middleware/CheckSubscription.php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class CheckSubscription
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): Response
    {
        /** @var \App\Models\User $user */
        $user = $request->user();

        // 1. A primeira verificação: o utilizador é um "admin" (dono de negócio)?
        //    Se não for (ex: for um 'client' ou 'super-admin'), deixamo-lo passar.
        //    Este segurança só se aplica aos donos de negócio.
        if (!$user->isAdmin()) {
            return $next($request);
        }

        // 2. A verificação principal: o período de teste OU a assinatura paga estão ativos?
        if ($user->isOnTrial() || $user->isSubscriptionActive()) {
            // Se pelo menos um estiver ativo, permite que o pedido continue.
            return $next($request);
        }

        // 3. Se nenhuma das condições for verdadeira, o acesso é bloqueado.
        //    Redirecionamos o utilizador para uma página a informar que a conta expirou.
        return redirect()->route('subscription.expired');
    }
}