<?php
// Em app/Listeners/StripeEventListener.php
namespace App\Listeners;

use App\Models\Plan;
use App\Models\User;
use Laravel\Cashier\Events\WebhookReceived;

class StripeEventListener
{
    public function handle(WebhookReceived $event): void
    {
        // Verificamos se o evento recebido é o de 'checkout.session.completed',
        // que significa que um pagamento foi concluído com sucesso.
        if ($event->payload['type'] === 'checkout.session.completed') {
            // Pegamos os dados da sessão de checkout
            $session = $event->payload['data']['object'];

            // Pegamos o ID do utilizador que guardámos quando criámos o checkout
            $user = User::find($session['client_reference_id']);

            if ($user && !$user->plan_id) { // Apenas se o utilizador ainda não tiver um plano
                // Pegamos o ID do plano do Stripe
                $stripePlanId = $session['display_items'][0]['plan']['id'];

                // Encontramos o nosso plano local correspondente
                $localPlan = Plan::where('stripe_plan_id', $stripePlanId)->first();

                if ($localPlan) {
                    // ATUALIZAMOS O NOSSO CAMPO PERSONALIZADO!
                    $user->plan_id = $localPlan->id;
                    $user->save();
                }
            }
        }
    }
}